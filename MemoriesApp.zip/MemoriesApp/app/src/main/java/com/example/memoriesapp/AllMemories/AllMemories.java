package com.example.memoriesapp.AllMemories;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.memoriesapp.R;

public class AllMemories extends AppCompatActivity {

    protected RecyclerView recyclerGetall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_all_memories);
        initView();
    }

    private void initView() {
        recyclerGetall = (RecyclerView) findViewById(R.id.recycler_getall);
    }
}
