package com.example.memoriesapp.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.memoriesapp.AllMemories.AllMemories;
import com.example.memoriesapp.Base.BaseActivity;
import com.example.memoriesapp.R;
import com.example.memoriesapp.dataBase.AppDataBase;
import com.example.memoriesapp.NewMemory.newMemory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;

public class MainActivity extends BaseActivity implements OnMapReadyCallback {

    protected MapView myMap;
    protected Button addMemoryButton;
    protected Button getAallButton;
    GoogleMap map;
    public static AppDataBase myDataBse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);
        initialaizeDtaBase();
        initView();
        myMap.onCreate(savedInstanceState);
        myMap.getMapAsync(this);
    }

    public AppDataBase initialaizeDtaBase() {

        myDataBse = AppDataBase.getInstance(MainActivity.this);
        return myDataBse;

    }


    private void initView() {
        myMap = (MapView) findViewById(R.id.myMap);
        addMemoryButton = (Button) findViewById(R.id.addMemory_button);
        getAallButton = (Button) findViewById(R.id.getAall_button);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
    }

    @Override
    protected void onStart() {
        super.onStart();
        myMap.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        myMap.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        myMap.onStop();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        myMap.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        myMap.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        myMap.onDestroy();
    }

    public void addMemory(View view){
        view = addMemoryButton;
        Intent intent = new Intent(MainActivity.this, newMemory.class);
        startActivity(intent);
    }

    public void getAllMemories(View view){
        view= getAallButton;
        Intent intent = new Intent(MainActivity.this, AllMemories.class);
        startActivity(intent);

    }



}
