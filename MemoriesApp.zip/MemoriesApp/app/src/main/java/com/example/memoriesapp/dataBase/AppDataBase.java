package com.example.memoriesapp.dataBase;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database( entities = {Memory.class} , version = 1,exportSchema = false)
public abstract class AppDataBase extends RoomDatabase {

    private  static AppDataBase mydataBase ;
   public abstract memoryDao memoryDao();
    public  static  final String DB_NAME ="Memory_database" ;

   public  static AppDataBase getInstance(Context context ){
     if(mydataBase == null)
    {
         Room.databaseBuilder(context ,AppDataBase.class,DB_NAME).fallbackToDestructiveMigration()
            .allowMainThreadQueries().build();

    }
    return  mydataBase ;
}




}
