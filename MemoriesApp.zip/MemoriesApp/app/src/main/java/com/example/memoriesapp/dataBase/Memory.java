package com.example.memoriesapp.dataBase;


import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Memory {

    @PrimaryKey(autoGenerate = true )
    int id  ;
    String titlee;
    String description ;
    String date ;
    String time ;


    public Memory() {
    }

   @Ignore
    public Memory(String titlee, String description, String date, String time) {
        this.titlee = titlee;
        this.description = description;
        this.date = date;
        this.time = time;
    }

    public String getTitlee() {
        return titlee;
    }

    public void setTitlee(String titlee) {
        this.titlee = titlee;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
