package com.example.memoriesapp.NewMemory;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.example.memoriesapp.Base.BaseActivity;
import com.example.memoriesapp.R;
import com.example.memoriesapp.dataBase.Memory;
import com.example.memoriesapp.main.MainActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class newMemory extends BaseActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    protected EditText title;
    protected EditText description;
    protected TextView currentTime;
    protected Button selectDate;
    protected Button saveMemory;
    protected TextView dateSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_new_memory);
        initView();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.select_date) {
            showDatePickerDialogs();
        } else if (view.getId() == R.id.save_memory) {
            getCurrentTime();

            if(checkValidate()!=true){
                custmToast(this," some fields empty");
                }
            else{

            Memory memory = new Memory(title.getText().toString(),
                    description.getText().toString(),
                    dateSelected.getText().toString(),
                    currentTime.getText().toString()
                 );

                MainActivity.myDataBse.memoryDao().addNewMemory(memory);


        }}
    }
    boolean checkValidate() {
        boolean validate = true;
        if (title.getText().toString().trim().isEmpty()||
                description.getText().toString().trim().isEmpty() ||
                dateSelected.getText().toString().trim().isEmpty()||
        currentTime.getText().toString().trim().isEmpty()) {
            validate = false;
        }

        return validate;

    }

    private void initView() {
        title = (EditText) findViewById(R.id.title);
        description = (EditText) findViewById(R.id.description);
        currentTime = (TextView) findViewById(R.id.current_time);
        selectDate = (Button) findViewById(R.id.select_date);
        selectDate.setOnClickListener(newMemory.this);
        saveMemory = (Button) findViewById(R.id.save_memory);
        saveMemory.setOnClickListener(newMemory.this);
        dateSelected = (TextView) findViewById(R.id.date_selected);
    }

    public void getCurrentTime() {
        SimpleDateFormat SdateFormat = new SimpleDateFormat("HH:mm:ss a");
        Calendar cal = Calendar.getInstance();
        String time = SdateFormat.format(cal.getTime());
        currentTime.setText(SdateFormat.format(cal.getTime()));
    }

    public void showDatePickerDialogs() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
             datePickerDialog.show();

    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
        String date = dayOfMonth + "/" + month + "/" + year;
        dateSelected.setText(date);

    }
}

